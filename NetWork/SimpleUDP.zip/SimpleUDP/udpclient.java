import java.net.*;
import java.io.*;


/**
 * This is a simple program for UDP client to send data to server
**/

class udpclient
{

	public static void main(String args[]) throws Exception

	{

		DatagramSocket ds = new DatagramSocket();

		byte[] b = "this is udp cliend".getBytes();

		InetAddress ip = InetAddress.getByName("localhost");

		int port = 2000;

		DatagramPacket dp = new DatagramPacket(b,b.length,ip,port);

		ds.send(dp);


	}

}
